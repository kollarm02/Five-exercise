﻿using System;
using System.Collections.Generic;
using System.IO;

namespace _1.feladat
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Fesztival> fest = new List<Fesztival>();
            string[] sor = File.ReadAllLines("C:\\Users\\Asus\\Downloads\\fesztival.txt");
            foreach (var item in sor)
            {
                string[] adatok = item.Split(',');
                Fesztival fesztival = new Fesztival(adatok[0], adatok[1], adatok[2], adatok[3], adatok[4], adatok[5], adatok[6]);
                fest.Add(fesztival);
            }

            // 2. és 3. feladat
            Console.WriteLine("2 és 3. feladat");
            Console.WriteLine("4. feladat");
            foreach (var item in fest)
            {
                Console.WriteLine($"{item.sorszam}; {item.nev}; {item.hotelm}; {item.fo}; {item.nap}; {item.fopernap}; {item.kedvezmenye}");
            }

            // 4. Feladat
            Console.WriteLine("5 és 6. Feladat");
            foreach (var fesztival in fest)
            {
                Console.WriteLine($"{fesztival.nev}: {fesztival.KoltottOsszeg()} Ft");
            }

            // 5. Feladat: Rendezés növekvő sorrendben
            Dictionary<string, double> osszesites = new Dictionary<string, double>();
            foreach (var fesztival in fest)
            {
                double osszeg = fesztival.KoltottOsszeg();
                if (!osszesites.ContainsKey(fesztival.nev))
                {
                    osszesites.Add(fesztival.nev, osszeg);
                }
            }
            List<KeyValuePair<string, double>> rendezettOsszesites = new List<KeyValuePair<string, double>>(osszesites);
            rendezettOsszesites.Sort((x, y) => x.Value.CompareTo(y.Value));
            foreach (var kvp in rendezettOsszesites)
            {
                Console.WriteLine($"{kvp.Key}: {kvp.Value} Ft");
            }

            // 6. Feladat: Legtöbbet költő személy keresése és kiíratása
            KeyValuePair<string, double> legtobbKoltotSzemely = rendezettOsszesites[rendezettOsszesites.Count - 1];
            Console.WriteLine($"A legtöbbet költő személy: {legtobbKoltotSzemely.Key}, {legtobbKoltotSzemely.Value} Ft");

            // 7. Feladat: Szállást kétszer foglaló személyek keresése és kiíratása
            List<string> ketSzallastFoglaloSzemelyek = new List<string>();
            Dictionary<string, int> szallasFoglalasok = new Dictionary<string, int>();
            foreach (var fesztival in fest)
            {
                if (szallasFoglalasok.ContainsKey(fesztival.nev))
                {
                    szallasFoglalasok[fesztival.nev]++;
                }
                else
                {
                    szallasFoglalasok.Add(fesztival.nev, 1);
                }
            }
            foreach (var kvp in szallasFoglalasok)
            {
                if (kvp.Value == 2)
                {
                    ketSzallastFoglaloSzemelyek.Add(kvp.Key);
                }
            }
            Console.WriteLine("A szállást kétszer foglaló személyek:");
            foreach (var szemely in ketSzallastFoglaloSzemelyek)
            {
                Console.WriteLine(szemely);
            }

            Console.ReadKey();
        }
    }
}
