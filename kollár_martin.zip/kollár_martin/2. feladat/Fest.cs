﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2.feladat
{
    internal class Fest
    {
        public int sorszam;
        public string nev;
        public string hotelm;
        public int fo;
        public int nap;
        public int fopernap;
        public string kedvezmenye;

        public Fest(string sorszam, string nev, string hotelm, string fo, string nap, string fopernap, string kedvezmenye)
        {
            this.sorszam = int.Parse(sorszam);
            this.nev = nev;
            this.hotelm = hotelm;
            this.fo = int.Parse(fo);
            this.nap = int.Parse(nap);
            this.fopernap = int.Parse(fopernap);
            this.kedvezmenye = kedvezmenye;
        }
        public double KoltottOsszeg()
        {
            double osszeg = nap * fo * fopernap; // Alap összeg kiszámítása
            if (kedvezmenye.ToLower() == "igen") // Ha van kedvezmény
            {
                osszeg *= 0.75; // 25% kedvezmény levonása
            }
            return osszeg;
        }
    }
}
