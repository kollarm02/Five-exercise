﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.IO;

namespace _2.feladat
{
    public partial class Form1 : Form
    {
        List<Fest> konyvlista = new List<Fest>();
        public Form1()
        {
            InitializeComponent();
            string[] sor = File.ReadAllLines("C:\\Users\\marti\\Downloads\\fesztival.txt");
            foreach (var item in sor)
            {
                string[] adatok = item.Split(',');
                Fest konyvek = new Fest(adatok[0], adatok[1], adatok[2], adatok[3], adatok[4], adatok[5], adatok[6]);
                konyvlista.Add(konyvek);
            }


            var rendezettLista = konyvlista.OrderByDescending(termek => termek.KoltottOsszeg());

            foreach (var legdragabbTermek in rendezettLista)
            {
                dataGridView1.Rows.Add(legdragabbTermek.nev, legdragabbTermek.KoltottOsszeg());
            }


            Dictionary<string, double> gyakoriFesztivalosok = new Dictionary<string, double>();

            // Gyakori fesztiválozók meghatározása és összegyűjtése
            foreach (var szemely in konyvlista)
            {
                if (GetFesztivalSzamlalo(szemely.nev) >= 3 && !gyakoriFesztivalosok.ContainsKey(szemely.nev))
                {
                    double osszeg = konyvlista.Where(x => x.nev == szemely.nev).Sum(x => x.KoltottOsszeg());
                    gyakoriFesztivalosok.Add(szemely.nev, osszeg);
                }
            }

            // Kiírás vagy más tevékenység
            foreach (var pair in gyakoriFesztivalosok)
            {
                ListViewItem item = new ListViewItem();
                item.Text = $"{pair.Key} legalább háromszor szerepelt a listában.";
                listView1.View = View.List;
                listView1.Items.Add(item);
            }


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private int GetFesztivalSzamlalo(string nev)
        {
            int szamlalo = 0;
            foreach (var szemely in konyvlista)
            {
                if (szemely.nev == nev)
                {
                    szamlalo++;
                }
            }
            return szamlalo;
        }


        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
